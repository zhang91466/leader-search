# -*- coding: UTF-8 -*-
"""
@time:2021/11/24
@author:zhangwei
@file:manage
"""
from l_search.cli import manager

if __name__ == '__main__':
    manager()


