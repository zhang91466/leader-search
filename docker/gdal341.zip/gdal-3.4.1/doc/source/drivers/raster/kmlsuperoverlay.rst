.. _raster.kmlsuperoverlay:

================================================================================
KMLSuperoverlay -- KMLSuperoverlay
================================================================================

.. shortname:: KMLSuperoverlay

.. built_in_by_default::

NOTE: Implemented as ``gdal/frmts/kmlsuperoverlay/kmlsuperoverlay.cpp``.


Driver capabilities
-------------------

.. supports_createcopy::

.. supports_georeferencing::

.. supports_virtualio::
