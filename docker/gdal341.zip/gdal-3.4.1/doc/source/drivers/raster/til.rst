.. _raster.til:

================================================================================
TIL -- EarthWatch/DigitalGlobe .TIL
================================================================================

.. shortname:: TIL

.. built_in_by_default::

NOTE: Implemented as ``gdal/frmts/til/tildataset.cpp``.

Driver capabilities
-------------------

.. supports_georeferencing::

.. supports_virtualio::
