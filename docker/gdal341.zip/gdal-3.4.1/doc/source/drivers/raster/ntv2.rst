.. _raster.ntv2:

================================================================================
NTv2 -- NTv2 Datum Grid Shift
================================================================================

.. shortname:: NTv2

.. built_in_by_default::

NOTE: Implemented as ``gdal/frmts/raw/ntv2dataset.cpp``.

Driver capabilities
-------------------

.. supports_createcopy::

.. supports_create::

.. supports_georeferencing::

.. supports_virtualio::

