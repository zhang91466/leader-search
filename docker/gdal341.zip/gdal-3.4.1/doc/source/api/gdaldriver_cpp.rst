.. _gdaldriver_cpp:

================================================================================
GDALDriver C++ API
================================================================================

GDALDriver class
----------------

.. doxygenclass:: GDALDriver
   :project: api
   :members:

GDALDriverManager class
-----------------------

.. doxygenclass:: GDALDriverManager
   :project: api
   :members:
